import React from 'react';
import { FaLinkedin } from "react-icons/fa6";
import { FaWhatsappSquare } from "react-icons/fa";
import { FaGithubSquare } from "react-icons/fa";
import { IoMdMail } from "react-icons/io";
import { CiLocationArrow1 } from "react-icons/ci";
import { FaArrowTrendUp } from "react-icons/fa6";
import Skills from '../Skills/index.js';
import Slider from '../Slider/index.js';
import '../Skills/skills.css';
import img from '../assets/main.png';

const Home = () => {
 
  return (
    <>
      <section className='h-[110%] mt-10 mb-14' id='home'>
        <div className='flex flex-row items-center justify-center mt-28 md:mt-16'>
          <div className='font-primaryType tracking-widest flex flex-col md:items-start w-screen items-center md:w-[40%]'>
            <h2 className='text-4xl font-medium'>Hello, I'm</h2>
            <h1 className='text-3xl md:text-6xl'><span className='text-orange-600 colorc'>G</span>aurav Singh</h1>

            <div className='typewriter'>
              <h2 className='text-2xl md:text-3xl font-medium pl-3 text-black'> A FRONTEND DEVELOPER</h2>
            </div>

            <p className='px-4 text-xl pt-4 md:px-0'>I'm a creative frontend developer and I'm</p>
            <p className='px-4 md:px-0 text-xl'>very passionate and dedicated to my work.</p>

            <div className='flex flex-row gap-5 items-center mt-9'>
              <a className='text-primaryFont bg-blue-700 rounded-md gap-2 px-3 py-3 inline-flex items-center text-xs hover:bg-purple-500 transition duration-1000 ease-in-out' href='https://x.com/GAURAVS78345096' target='_blank'>
                Let's talk<CiLocationArrow1 className='text-lg ' />
              </a>

              <a href='https://drive.google.com/file/d/1ZcfNCrkRHx8AQeosyubwsCVaoEjjxnCQ/preview' className='text-black font-semibold inline-flex items-center gap-2  hover:text-blue-600 transition duration-300'>Portfolio <FaArrowTrendUp  className='text-shadow'/></a>
            </div>

            <div className='text-2xl flex flex-row items-center gap-4 md:gap-8 mx-4 mt-10'>
              <h1 className='text-base font-semibold'>Check Out My</h1>
              <a href='https://www.linkedin.com/in/gaurav-singh-5a0634338'> <FaLinkedin /></a>
              <a href='https://github.com/gauravjethi1308'> <FaGithubSquare /></a>
              <a href='mailto:gauravjethi@gmail.com'> <IoMdMail /></a>
              <a href='https://wa.me/918755207262?text=Hi%20Gaurav' target='_blank'> <FaWhatsappSquare  /></a>
            </div>
          </div>

          <div>
            <img src={img} alt='dp' className='hidden md:block h-[500px] w-[400px] pt-7' />
          </div>
        </div>
      </section>

      <section className='mt-20 ' id='skills'>
        <Skills />
      </section>

      <section  id='works'>
        <Slider />
      </section>
    </>
  );
}

export default Home;
