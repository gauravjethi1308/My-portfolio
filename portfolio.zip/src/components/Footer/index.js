import React from 'react'
import { PiArrowBendDownRight } from "react-icons/pi";
const Footer = () => {
  return (
    <footer className='font-primaryType px-9 md:px-10 my-16 ' id='contact'> 
   <div className='flex flex-col gap-5'>
    <div className='flex flex-col items-start gap-12 md:flex-row md:items-center justify-around'>
    <div className='flex flex-col gap-14'>
<div className='text-4xl text-green-900'>
      <h1>Let's make something</h1>
      <h1>amazing together.</h1>
      </div>


      <div>
        <h1 className='text-3xl text-orange-600 underline underline-offset-4'>Lets Connect</h1>
       <a href='https://x.com/GAURAVS78345096' target='_blank ' > <PiArrowBendDownRight className='text-5xl hover:text-red-500' /></a>
      </div>
    </div>

<div>
<div className='flex flex-col gap-5'>
<h1 className='text-2xl font-semibold'>Information</h1>
<p className='text-base'>UTTARAKHAND , PITHORAGARH</p>
<ul className='flex flex-col gap-y-8  text-sm font-medium font-thirdtype'>
<a className='hover:text-blue-700 hover:underline underline-offset-4 transition-all duration-1000 ease-in-out' href='#home'>ABOUT ME</a>
<a className='hover:text-blue-700 hover:underline underline-offset-4 transition-all duration-1000 ease-in-out'  href='#skills'>SKILLS</a>
<a className='hover:text-blue-700 hover:underline underline-offset-4 transition-all duration-1000 ease-in-out' href='#works'>WORKS</a>
<a className='hover:text-blue-700 hover:underline underline-offset-4 transition-all duration-1000 ease-in-out' href='#contact'>CONTACT</a>



</ul>


</div>
    </div>
</div>

<div>
    <div className='border-t border-green-900 w-full my-4'/>


<div className='flex flex-row items-center justify-around'>
<div className='flex flex-row gap-5 items-center'>
  <h1 className='text-3xl  font-extralight font-thirdtype text-black'><span className='colorc'>G</span>aurav</h1>
<p>|</p>
  <h1 className='text-sm'>&copy;2025.All Rights Reserved</h1>
</div>

<div>
 <h1 className='text-sm'>Designed by Gaurav</h1> 
</div>
</div>
</div>

    </div>
</footer>
  );
};

export default Footer
