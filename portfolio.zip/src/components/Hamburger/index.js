import React, { useState, useEffect } from "react";
import { VscMenu } from "react-icons/vsc";
import { FaStarHalfStroke } from "react-icons/fa6";
import { RxCross2 } from "react-icons/rx";
import { FaLinkedin } from "react-icons/fa6";
import { FaWhatsappSquare } from "react-icons/fa";
import { FaGithubSquare } from "react-icons/fa";
import { IoMdMail } from "react-icons/io";



const Hamburger = () => {
  const [isOpen, setIsOpen] = useState(false);

  // Prevent scrolling when the hamburger menu is open
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "auto";
    }
  }, [isOpen]);

  return (
    <div className="block ml-2 md:hidden">
      <div className="relative flex flex-col items-start rounded-lg">
        <button
          onClick={() => setIsOpen((prev) => !prev)}
          className="text-white text-xl active:text-black"
        >
          {!isOpen ? (
            <VscMenu className="text-black text-3xl" />
          ) : (
            <RxCross2 className="text-primaryFont text-3xl" />
          )}
        </button>

        {/* Hamburger Menu Content */}
        {isOpen && (
          <div className="bg-[#0f172a] fixed inset-0 h-screen w-screen p-6 z-50">
            {/* Cross Icon and Main Heading */}
            <div className="flex items-center justify-between mb-8">
              <RxCross2
                className="text-primaryFont text-3xl cursor-pointer"
                onClick={() => setIsOpen(false)}
              />
              <div className="text-center flex-1">
                  <div  className="text-2xl text-white">
                  <h1 className='  text-3xl  font-extralight font-thirdtype text-white text-center'><span className='colorc'>G</span>aurav</h1>

                  </div>
                
                <div className="flex flex-row gap-1 text-xs text-white  justify-center">
                <FaStarHalfStroke />
                            <FaStarHalfStroke />
                            <FaStarHalfStroke />
                            <FaStarHalfStroke />
                            <FaStarHalfStroke />
                            <FaStarHalfStroke />
                </div>
              </div>
            </div>

            <div className="w-full h-px bg-gray-600 mb-8"></div>

            {/* Links Section */}
              <ul  className="flex flex-col items-start gap-y-4 text-sm pl-4">
                <li>
                  <a
                    href="'#home'"
                    className="text-white font-primaryType hover:underline hover:underline-offset-8"
                  >
                    ABOUT ME
                  </a>
                </li>
                <li>
                  <a
                    href="#skills"
                    className="text-white font-primaryType hover:underline hover:underline-offset-8"
                  >
                    SKILLS
                  </a>
                </li>
                <li>
                  <a
                    href="#works"
                    className="text-white font-primaryType hover:underline hover:underline-offset-8"
                  >
                    WORKS
                  </a>
                </li>
                <li>
                  <a
                    href="#contact"
                    className="text-white font-primaryType hover:underline hover:underline-offset-8"
                  >
                    CONTACT
                  </a>
                </li>
              </ul>
            

            {/* Address Section */}
            <div className="text-white flex flex-col items-start pl-4 mt-8">
              <h1 className="text-lg">UTTARAKHAND ,PITHORAGARH</h1>
              <h2 className="text-sm mt-2">©2025.All Rights Reserved</h2>
              
            </div>

            {/* Footer  Section */}
                
             
              <div className="flex flex-row gap-4 mt-4 text-white text-2xl">
                             <a href='https://www.linkedin.com/in/gaurav-singh-5a0634338'> <FaLinkedin /></a>
                             <a href='https://github.com/gauravjethi1308'> <FaGithubSquare /></a>
                             <a href='mailto:gauravjethi@gmail.com'> <IoMdMail /></a>
                             <a href='https://wa.me/918755207262?text=Hi%20Gaurav' target='_blank'> <FaWhatsappSquare /></a>
               
              </div>
            
          </div>
        )}
      </div>
    </div>
  );
};

export default Hamburger;