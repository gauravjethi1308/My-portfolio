import React from 'react'
import { HiOutlinePhoneOutgoing } from "react-icons/hi";
import Hamburger from '../Hamburger/index';
import '../Skills/skills.css'
const Header = () => {
  return (
    <header className='w-[100%]   mt-2 '>
<Hamburger/>

<div className='md:flex flex-row items-center justify-between mt-4 mx-3'>

<div className='-mt-12 md:mt-0'>
  <h1 className='  text-3xl  font-extralight font-thirdtype text-black text-center'><span className='colorc'>G</span>aurav</h1>
</div>

<div className='hidden md:flex flex-row gap-10 font-secondaryType text-xl'>
<a href='#home' className='navhover hover:text-blue-800'>ABOUT ME</a>
<a href='#skills' className='navhover hover:text-blue-800'>SKILLS</a>
<a href='#works' className='navhover hover:text-blue-800'>WORKS</a>
<a href='#contact' className='navhover hover:text-blue-800'>CONTACT</a>

</div>


<div className=' hidden md:flex flex-row gap-3 items-center font-fourthtype text-xl'>
  <a className=' md:text-base font-semibold' href='tel:+91 9389035287'>+91 9389035287</a>
  <button className= ' bg-gray-200 md:py-2 px-4 rounded-full md:flex items-center hover:bg-orange-300 transition duration-1000 ease-in-out'>
   <a href='tel:+91 9389035287'> <HiOutlinePhoneOutgoing className='text-green-600'/></a>
  </button>
</div>





</div>

      
    </header>
  )
}

export default Header
