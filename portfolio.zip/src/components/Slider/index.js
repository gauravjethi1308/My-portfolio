import { Swiper, SwiperSlide } from "swiper/react";
import "swiper/css";
import "../Slider/style.css";
import "swiper/css/pagination";
import "swiper/css/navigation";
import { CiLocationArrow1 } from "react-icons/ci";
import { Autoplay, Pagination, Navigation } from "swiper/modules";
import image from "../../../public/assets/Slider1.jpg";
import image2 from "../../../public/assets/Slider2.jpg";
import image3 from "../../../public/assets/Slider3.jpg";
import image4 from "../../../public/assets/Slider4.jpg";

const Slider = () => {
  const projectLinks = [
    "https://github.com/gauravjethi1308/Stay-Hotel-Booking-Website",
    "https://github.com/gauravjethi1308/My-portfolio",
    "https://github.com/gauravjethi1308/To-do-list",
    "https://github.com/gauravjethi1308/project4",
  ];

  return (
    <section className="h-[100%] bg-[rgb(249,240,232)] flex flex-col items-center justify-center">
      <h1 className="text-4xl md:text-6xl font-secondaryType font-medium text-center mt-14">
        <span className="text-violet-600">M</span>y Latest Works
      </h1>
      <a
        href="https://github.com/gauravjethi1308"
        className="underline underline-offset-4 text-orange-600 text-center hover:text-green-700"
      >
        Explore More Work
      </a>

      <Swiper
        slidesPerView={1}
        spaceBetween={10}
        autoplay={{
          delay: 2500,
          disableOnInteraction: false,
        }}
        navigation={true}
        pagination={{ clickable: true }}
        breakpoints={{
          640: { slidesPerView: 1 },
          768: { slidesPerView: 3 },
        }}
        modules={[Autoplay, Pagination, Navigation]}     
           className="mySwiper mt-7">
            
        {[image, image2, image3, image4].map((img, index) => (
          <SwiperSlide key={index}>
            <div className="card">
              <img src={img} alt={`image${index + 1}`} className="card-image" />
              <div className="card-footer">
                <a href={projectLinks[index]} className="card-button" target="_blank" rel="noopener noreferrer">
                  View Project <CiLocationArrow1 className="text-lg" />
                </a>
              </div>
            </div>
          </SwiperSlide>
        ))}
      </Swiper>
    </section>
  );
};

export default Slider;
