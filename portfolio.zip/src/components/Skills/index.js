import React from 'react';
import { FaHtml5, FaCss3Alt, FaJs, FaReact, FaBootstrap } from "react-icons/fa";
import { RiTailwindCssLine } from "react-icons/ri";
import '../Skills/skills.css';

const Skills = () => {
  return (
    <section className='text-black font-primaryType bg-[rgb(248,247,241)] py-12 px-6 md:px-16 lg:px-24'>
      {/* Main Container */}
      <div className='max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-12'>

        {/* Left: Skills & Experience */}
        <div className='flex flex-col gap-8'>

          {/* Heading */}
          <h1 className='text-4xl md:text-5xl font-semibold text-center md:text-left'>
            <span className='text-red-500'>S</span>kills & Experience
          </h1>

          {/* Description */}
          <p className='text-lg font-fourthtype'>
            As a proficient front-end developer, I specialize in crafting responsive, user-friendly, and visually stunning web applications. With a strong foundation in React JS, I excel at building dynamic, interactive interfaces that provide seamless user experiences.
          </p>

          {/* Skills Grid */}
          <div>
            <h2 className='text-3xl font-semibold mb-4 text-center'>Skills</h2>
            <div className='grid grid-cols-3 sm:grid-cols-3 gap-6'>
              {[
                { icon: <FaHtml5 className='text-orange-500 text-3xl' />, name: 'HTML' },
                { icon: <FaCss3Alt className='text-blue-500 text-3xl' />, name: 'CSS' },
                { icon: <FaJs className='text-yellow-500 text-3xl' />, name: 'JavaScript' },
                { icon: <FaBootstrap className='text-purple-500 text-3xl' />, name: 'Bootstrap' },
                { icon: <FaReact className='text-blue-600 text-3xl' />, name: 'React' },
                { icon: <RiTailwindCssLine className='text-teal-500 text-3xl' />, name: 'Tailwind' },
              ].map((skill, index) => (
                <div key={index} className='flex flex-col items-center gap-2'>
                  <div className='border border-gray-800 rounded-full w-14 h-14 flex items-center justify-center bg-black shadow-md'>
                    {skill.icon}
                  </div>
                  <h1 className='text-sm font-semibold'>{skill.name}</h1>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right: Education (Minimal & Classy Design) */}
        <div className='flex flex-col gap-6'>
          {/* Heading */}
          <h1 className='text-4xl font-semibold font-secondaryType'><span className='text-fuchsia-600'>E</span>DUCATION</h1>

          {/* Education Items */}
          <div className='space-y-6'>
            {[
              { school: 'APS PITHORAGARH, UTTARAKHAND', duration: '2019-2020', degree: 'CLASS-X' },
              { school: 'KV PITHORAGARH, UTTARAKHAND', duration: '2021-2022', degree: 'CLASS-XII' },
              { school: 'MCSTM PITHORAGARH, UTTARAKHAND', duration: '2022-2025', degree: 'GRADUATION' },
              { school: 'Iria Research, UTTARAKHAND', duration: '2024(Dec)-2025(Feb)', degree: 'INTERNSHIP' },
            ].map((edu, index) => (
              <div key={index} className='flex flex-col gap-2'>
                <h1 className='text-lg font-semibold text-red-600'>{edu.school}</h1>
                <hr className='w-full h-[2px] bg-black my-2' />
                <div className='flex justify-between text-sm font-medium text-gray-700'>
                  <p>{edu.duration}</p>
                  <p>{edu.degree}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>
    </section>
  );
};

export default Skills;
