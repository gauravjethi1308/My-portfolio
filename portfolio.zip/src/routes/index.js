import { createBrowserRouter, Navigate } from "react-router-dom";
import Home from "../components/Home";
import Applayout from "../components/layout/applayout";

export const routes = createBrowserRouter([

  {
   
    element: <Applayout />,
children: [

      {
        index: true, // Indicates this is the default route for "/"
        element: <Navigate to="/home" />,
      },
      {
        path: "/home",
        element: <Home />,
      },
      

    ],
  },
]);
